public class CommandLineArray {
    public static void main(String[] args) {
        System.out.println("Array elements from command line:");
        for (String arg : args) {
            System.out.print(arg + " ");
        }
    }
}
